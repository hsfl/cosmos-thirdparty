#!/bin/sh

rm -rf exlcm
rm -f MySubscriber.class SendMessage.class
