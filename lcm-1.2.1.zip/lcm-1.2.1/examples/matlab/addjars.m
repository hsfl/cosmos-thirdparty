javaaddpath my_types.jar
javaaddpath ../../lcm-java/lcm.jar
